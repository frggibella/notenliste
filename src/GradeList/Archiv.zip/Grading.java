package GradeList;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.io.OutputStream;


/**
 * Created by beahildehrandt on 15.11.15.
 */
public class Grading{
    private JTextField onePercent;
    private JTextField oneThreePercent;
    private JTextField oneSevenPercent;
    private JTextField twoPercent;
    private JTextField twoThreePercent;
    private JTextField twoSevenPercent;
    private JTextField threePercent;
    private JTextField threeThreePercent;
    private JTextField threeSevenPercent;
    private JTextField fourPercent;

    private JFrame jFrame;

    public Grading(JFrame jFrame){
        this.jFrame = jFrame;
    }









}
